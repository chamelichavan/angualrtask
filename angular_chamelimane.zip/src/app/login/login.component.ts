import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit(): void {
  }
  loginObj:any={
    "username":"",
    "password":""
  }
  loginUser(){
    if(this.loginObj.username=="admin"&& this.loginObj.password=="1234"){
      localStorage.setItem("loggednuser",this.loginObj.username);
      this.route.navigateByUrl("dashboard");
    }
      else{
        alert("username and password is incorrect")
      }
    }
  }


